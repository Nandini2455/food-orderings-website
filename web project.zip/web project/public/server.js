const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require('mongodb');

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// MongoDB connection URI
const mongoURI = 'mongodb://localhost:27017';
const dbName = 'orders';
const collectionName = 'orderDetails';

// Connect to MongoDB
MongoClient.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true }, (err, client) => {
    if (err) {
        console.error('Error connecting to MongoDB:', err);
        return;
    }

    console.log('Connected to MongoDB');

    const db = client.db(dbName);
    const collection = db.collection(collectionName);

    // Route to handle order submission
    app.post('/place-order', (req, res) => {
        const orderDetails = req.body; // Assuming order details are sent in the request body
        collection.insertOne(orderDetails, (err, result) => {
            if (err) {
                console.error('Error inserting order details:', err);
                res.status(500).send('Error placing order');
                return;
            }
            console.log('Order placed successfully:', result.ops[0]);
            res.status(200).send('Order placed successfully');
        });
    });

    app.listen(PORT, () => {
        console.log(`Server is listening on port ${PORT}`);
    });
});
